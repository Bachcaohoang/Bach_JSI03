const firebaseConfig = {
    apiKey: "AIzaSyA89ctRBbFYq39fVxuBsttry8ZKiK9duws",
    authDomain: "authentication-web-6e7d9.firebaseapp.com",
    projectId: "authentication-web-6e7d9",
    storageBucket: "authentication-web-6e7d9.appspot.com",
    messagingSenderId: "1080769581444",
    appId: "1:1080769581444:web:7534bfc5e85b8598f34dd1",
    measurementId: "G-GJV149PWJB"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
  
  function signIn() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    auth.signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        showUserInfo(user);
      })
      .catch((error) => {
        console.error('Error signing in:', error.message);
      });
  }
  
  function signUp() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    auth.createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        showUserInfo(user);
      })
      .catch((error) => {
        console.error('Error signing up:', error.message);
      });
  }
  
  function signOut() {
    auth.signOut()
      .then(() => {
        console.log('Signed out successfully');
        hideUserInfo();
      })
      .catch((error) => {
        console.error('Error signing out:', error.message);
      });
  }
  
  function showUserInfo(user) {
    document.getElementById('user-email').textContent = `Welcome, ${user.email}!`;
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('user-info').style.display = 'block';
  }
  
  function hideUserInfo() {
    document.getElementById('user-email').textContent = '';
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('user-info').style.display = 'none';
  }
  